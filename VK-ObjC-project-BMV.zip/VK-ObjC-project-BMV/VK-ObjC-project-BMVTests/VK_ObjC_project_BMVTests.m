//
//  VK_ObjC_project_BMVTests.m
//  VK-ObjC-project-BMVTests
//
//  Created by max on 11.02.18.
//  Copyright © 2018 Maksim Bakharev. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface VK_ObjC_project_BMVTests : XCTestCase

@end

@implementation VK_ObjC_project_BMVTests


@end
