//
//  BMVvkPhotosCollectionViewCell.h
//  VK-ObjC-project-BMV
//
//  Created by max on 28.01.18.
//  Copyright © 2018 Maksim Bakharev. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface BMVvkPhotosCollectionViewCell : UICollectionViewCell


@property (nonatomic,strong) UIImage *image;


@end
