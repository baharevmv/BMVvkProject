//
//  UserModel.m
//  VK-ObjC-project-BMV
//
//  Created by max on 14.01.18.
//  Copyright © 2018 Maksim Bakharev. All rights reserved.
//

#import "BMVVkUserModel.h"

@implementation BMVVkUserModel

@end
