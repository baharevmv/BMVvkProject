//
//  VKAccessToken+CoreDataClass.m
//  VK-ObjC-project-BMV
//
//  Created by max on 25.01.18.
//  Copyright © 2018 Maksim Bakharev. All rights reserved.
//
//

#import "VKAccessToken+CoreDataClass.h"

@implementation VKAccessToken

@end
