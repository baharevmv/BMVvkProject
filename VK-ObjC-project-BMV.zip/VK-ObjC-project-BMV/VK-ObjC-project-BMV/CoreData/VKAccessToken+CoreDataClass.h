//
//  VKAccessToken+CoreDataClass.h
//  VK-ObjC-project-BMV
//
//  Created by max on 25.01.18.
//  Copyright © 2018 Maksim Bakharev. All rights reserved.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface VKAccessToken : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "VKAccessToken+CoreDataProperties.h"
