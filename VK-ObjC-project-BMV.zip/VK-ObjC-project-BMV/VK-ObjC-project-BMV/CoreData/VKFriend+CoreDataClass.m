//
//  VKFriend+CoreDataClass.m
//  
//
//  Created by max on 05.02.18.
//
//

#import "VKFriend+CoreDataClass.h"

@implementation VKFriend

@end
