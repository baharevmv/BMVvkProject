//
//  VKFriend+CoreDataClass.h
//  
//
//  Created by max on 12.02.18.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface VKFriend : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "VKFriend+CoreDataProperties.h"
