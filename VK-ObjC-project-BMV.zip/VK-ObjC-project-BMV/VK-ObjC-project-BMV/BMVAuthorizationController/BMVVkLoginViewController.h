//
//  BMVLoginViewController.h
//  VK-ObjC-project-BMV
//
//  Created by max on 11.01.18.
//  Copyright © 2018 Maksim Bakharev. All rights reserved.
//

#import <UIKit/UIKit.h>


/**
 Класс для авторизации в соц. сети vk.com, и для получения Ключа доступа пользователя.
 */
@interface BMVVkLoginViewController : UIViewController

@end
